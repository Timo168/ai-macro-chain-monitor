-------------------------------------------------------------------
Series ID: DGS10
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=DGS10
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations by Vintage Date, All Observations
File Created: 2026-10-10 9:19 PM CDT
-------------------------------------------------------------------

---------------------------------------------------------------------------------------------------  ---------------  -------------
Title                                                                                                Real-Time Start  Real-Time End
Market Yield on U.S. Treasury Securities at 10-Year Constant Maturity,                               2014-04-02       Current
Quoted on an Investment Basis
Source
Board of Governors of the Federal Reserve System (US)                                                2005-06-28       Current
Release
H.15 Selected Interest Rates                                                                         2005-06-28       Current
Units
Percent                                                                                              2005-06-28       Current
Frequency
Daily                                                                                                2005-06-28       Current
Seasonal Adjustment
Not Seasonally Adjusted                                                                              2005-06-28       Current
Notes
H.15 Statistical Release                                                                             2025-01-07       Current
(https://www.federalreserve.gov/releases/h15/current/h15.pdf) notes
and Treasury Yield Curve Methodology
(https://www.treasury.gov/resource-center/data-chart-center/interest-rates/Pages/yieldmethod.aspx).
For questions on the data, please contact the data source
(https://www.federalreserve.gov/apps/ContactUs/feedback.aspx?refurl=/releases/h15/%).
For questions on FRED functionality, please contact us here
(https://fred.stlouisfed.org/contactus/).</p>
---------------------------------------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2026-10-10
----------

