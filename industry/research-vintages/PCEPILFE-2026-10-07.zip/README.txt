-------------------------------------------------------------------
Series ID: PCEPILFE
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=PCEPILFE
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations by Vintage Date, All Observations
File Created: 2026-10-07 9:48 PM CDT
-------------------------------------------------------------------

---------------------------------------------------------------------------------------------------------------------------------------------  ---------------  -------------
Title                                                                                                                                          Real-Time Start  Real-Time End
Personal Consumption Expenditures Excluding Food and Energy                                                                                    2000-08-01       Current
(Chain-Type Price Index)
Source
U.S. Bureau of Economic Analysis                                                                                                               2000-08-01       Current
Release
Personal Income and Outlays                                                                                                                    2000-08-01       Current
Units
Index 2017=100                                                                                                                                 2023-09-29       Current
Frequency
Monthly                                                                                                                                        2000-08-01       Current
Seasonal Adjustment
Seasonally Adjusted                                                                                                                            2000-08-01       Current
Notes
BEA Account Code: DPCCRG  The Personal Consumption Expenditures Price                                                                          2019-06-28       Current
Index is a measure of the prices that people living in the United
States, or those buying on their behalf, pay for goods and services.
The change in the PCE price index is known for capturing inflation (or
deflation) across a wide range of consumer expenses and reflecting
changes in consumer behavior. For example, if car prices rise, car
sales may decline while bicycle sales increase.   The PCE Price Index
is produced by the Bureau of Economic Analysis (BEA), which revises
previously published PCE data to reflect updated information or new
methodology, providing consistency across decades of data that's
valuable for researchers. They also offer the series as a Chain-Type
index and excluding food and energy products, as above. The PCE price
index less food excluding food and energy is used primarily for
macroeconomic analysis and forecasting future values of the PCE price
index.  The PCE Price Index is similar to the Bureau of Labor
Statistics' consumer price index for urban consumers. The two indexes,
which have their own purposes and uses, are constructed differently,
resulting in different inflation rates.  For more information on the
PCE price index, see: U.S. Bureau of Economic Analysis, Guide to the
National Income and Product Accounts of the United States (NIPA)
(https://www.bea.gov/national/pdf/nipaguid.pdf)  U.S. Bureau of
Economic Analysis, Personal Consumption Expenditures Price Index
(https://www.bea.gov/data/personal-consumption-expenditures-price-index)
U.S. Bureau of Economic Analysis, Prices & Inflation
(https://www.bea.gov/resources/learning-center/what-to-know-prices-inflation)
U.S. Bureau of Labor Statistics, Differences between the Consumer
Price Index and the Personal Consumption Expenditure Price Index
(https://www.bls.gov/opub/btn/archive/differences-between-the-consumer-price-index-and-the-personal-consumption-expenditures-price-index.pdf)
---------------------------------------------------------------------------------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2026-10-07
----------

