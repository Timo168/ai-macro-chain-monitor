-------------------------------------------------------------------
Series ID: ICSA
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=ICSA
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations by Vintage Date, All Observations
File Created: 2026-10-08 8:27 PM CDT
-------------------------------------------------------------------

---------------------------------------------------------------------  ---------------  -------------
Title                                                                  Real-Time Start  Real-Time End
Initial Claims                                                         2009-05-28       Current
Source
U.S. Employment and Training Administration                            2009-05-28       Current
Release
Unemployment Insurance Weekly Claims Report                            2009-05-28       Current
Units
Number                                                                 2009-05-28       Current
Frequency
Weekly, Ending Saturday                                                2009-05-28       Current
Seasonal Adjustment
Seasonally Adjusted                                                    2009-05-28       Current
Notes
An initial claim is a claim filed by an unemployed individual after a  2009-05-28       Current
separation from an employer. The claim requests a determination of
basic eligibility for the Unemployment Insurance program.
---------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2026-10-08
----------

