-------------------------------------------------------------------
Series ID: DFII10
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=DFII10
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations by Vintage Date, All Observations
File Created: 2026-10-03 3:57 AM CDT
-------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------
Title                                                                                                                          Real-Time Start  Real-Time End
Market Yield on U.S. Treasury Securities at 10-Year Constant Maturity,                                                         2019-07-01       Current
Quoted on an Investment Basis, Inflation-Indexed
Source
Board of Governors of the Federal Reserve System (US)                                                                          2005-10-12       Current
Release
H.15 Selected Interest Rates                                                                                                   2005-10-12       Current
Units
Percent                                                                                                                        2005-10-12       Current
Frequency
Daily                                                                                                                          2005-10-12       Current
Seasonal Adjustment
Not Seasonally Adjusted                                                                                                        2005-10-12       Current
Notes
H.15 Statistical Release notes                                                                                                 2025-01-07       Current
(https://www.federalreserve.gov/releases/h15/default.htm) and the
Treasury Yield Curve Methodology
(https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics/treasury-yield-curve-methodology).
For questions on the data, please contact the data source
(https://www.federalreserve.gov/apps/ContactUs/feedback.aspx?refurl=/releases/h15/%).
For questions on FRED functionality, please contact us here
(https://fred.stlouisfed.org/contactus/).</p>
-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2026-10-02
----------

