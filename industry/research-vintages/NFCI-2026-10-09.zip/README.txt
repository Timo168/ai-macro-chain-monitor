-------------------------------------------------------------------
Series ID: NFCI
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=NFCI
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations by Vintage Date, All Observations
File Created: 2026-10-09 7:09 PM CDT
-------------------------------------------------------------------

---------------------------------------------------------------------  ---------------  -------------
Title                                                                  Real-Time Start  Real-Time End
Chicago Fed National Financial Conditions Index                        2011-05-25       Current
Source
Federal Reserve Bank of Chicago                                        2011-05-25       Current
Release
Chicago Fed National Financial Conditions Index                        2011-05-25       Current
Units
Index                                                                  2011-05-25       Current
Frequency
Weekly, Ending Friday                                                  2011-05-25       Current
Seasonal Adjustment
Not Seasonally Adjusted                                                2011-05-25       Current
Notes
The Chicago Fed's National Financial Conditions Index (NFCI) provides  2019-06-26       Current
a comprehensive weekly update on U.S. financial conditions in money
markets, debt and equity markets and the traditional and "shadow"
banking systems. Positive values of the NFCI indicate financial
conditions that are tighter than average, while negative values
indicate financial conditions that are looser than average.  For
further information, please visit the Federal Reserve Bank of Chicago
(http://www.chicagofed.org/webpages/publications/nfci/index.cfm).
---------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2026-10-09
----------

